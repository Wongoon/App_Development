package com.example.week15;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity4 extends AppCompatActivity {
    Button back;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        back = (Button) findViewById(R.id.back);

        String report = "";
        SensorManager manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensors = manager.getSensorList(Sensor.TYPE_ALL);
        report += "전체 센서 수 : " + sensors.size() + "\n";
        int i = 0;
        for (Sensor s : sensors) {
            report += "" + i++ + " name : " + s.getName() + "\n power : "
                    + s.getPower() + "\n res : " + s.getResolution()
                    + "\n range : " + s.getMaximumRange() + "\n\n";
        }
        TextView text = (TextView) findViewById(R.id.text1);
        text.setText(report);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity4.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}