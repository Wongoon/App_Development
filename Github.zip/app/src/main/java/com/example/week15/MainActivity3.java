package com.example.week15;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity3 extends AppCompatActivity {
    VideoView videoView;
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        videoView = (VideoView) findViewById(R.id.videoview);
        back = (Button) findViewById(R.id.back);

        MediaController mc = new MediaController(this) {
            @Override
            public void show() { super.show(0); }
        };

        videoView.setMediaController(mc);
        videoView.setVideoURI(Uri.parse("android:resource://" + getPackageName() + "/" + R.raw.trailer));
        videoView.start();
        videoView.requestFocus();
        mc.setEnabled(true);
        mc.show(0);



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity3.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}